package hotbitinfotech.com.frigo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class BarcodeListItems extends AppCompatActivity {

    private Toolbar barcodeToolbar;
    private RecyclerView barcodeRecyclerview;

    private ArrayList<Model> arrayListBarcode = new ArrayList<>();
    private ArrayList<Note> arrayListDB = new ArrayList<>();
    private BarcodeItem_Adapter adapterBarcode;
 String TAG="list,,,";
    private DatabaseHelper db;
    ProgressDialog progressDoalog;
    private ConstraintLayout barcodeConstraintLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barcode_list_items);

        db = new DatabaseHelper(this);

        //TODO:- widget
        barcodeToolbar = findViewById(R.id.toolbar);
        barcodeRecyclerview = findViewById(R.id.recyclerViewGloble);
        barcodeConstraintLayout = findViewById(R.id.constraintLayoutListBarcode);

        //TODO:- click event on toolbar.
        barcodeToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BarcodeListItems.this, MainActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET));
                finish();
            }
        });
        //TODO:- get barcode data.


        arrayListDB.addAll(db.getAllBarcodeData());
        String pName, pBarcodeDate, pBarcodeManual, pBarcodeQuantit;

        if (arrayListDB.size() != 0) {
            for (int i = 0; i < arrayListDB.size(); i++) {
                pName = arrayListDB.get(i).getName();
                pBarcodeDate = arrayListDB.get(i).getEpiredata();
                pBarcodeManual = arrayListDB.get(i).getManualbarcode();
                pBarcodeQuantit = arrayListDB.get(i).getQuantity();


            }


        } else {

        }
        checkBarcodeToserver();
        Toast.makeText(BarcodeListItems.this, "Please wait", Toast.LENGTH_SHORT).show();

    }
    private void checkBarcodeToserver() {
        progressDoalog = new ProgressDialog(BarcodeListItems.this);


        progressDoalog.setMessage("Please wait");

        progressDoalog.show();
        progressDoalog.setCancelable(false);
        arrayListBarcode.clear();
        String URL = "http://hotbitinfotech.com/frigo/get_all_info.php";
        StringRequest request = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e(TAG, "onResponse: check barcode " + response);
                try {
                    JSONArray jsonArray = new JSONArray(response);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        final JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String status = jsonObject.getString("status");
                        if (status.equalsIgnoreCase("false"))
                        {
                            progressDoalog.dismiss();
                        }
                        String product_name = jsonObject.getString("product_name");
                        String product_expire_date = jsonObject.getString("product_expire_date");
                        String product_manual_bar = jsonObject.getString("product_manual_bar");
                        String product_quantity = jsonObject.getString("product_quantity");
                        Log.e(TAG, "onResponse:---------- "+product_name+ product_expire_date+ product_manual_bar+ product_quantity );

                        arrayListBarcode.add(new Model(product_name, product_expire_date, product_manual_bar, product_quantity));
                        progressDoalog.dismiss();

                        if (status.equalsIgnoreCase("true")) {

                        } else {
                            Toast.makeText(BarcodeListItems.this, "DATA NOT AVAILABLE", Toast.LENGTH_SHORT).show();


                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    //TODO:- insert new data to local data

                                }
                            }, 500);
                        }
                    }

                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
                    barcodeRecyclerview.setLayoutManager(layoutManager);
                    adapterBarcode = new BarcodeItem_Adapter(BarcodeListItems.this, arrayListBarcode);
                    barcodeRecyclerview.setAdapter(adapterBarcode);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDoalog.dismiss();
                Log.e(TAG, "onErrorResponse: " + error.getMessage());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                HashMap<String, String> param = new HashMap<>();
                param.put("status", "true");
                Log.e(TAG, "getParams:---get "+param );
                return param;
            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(request);
    }
    private void remove(final String barcodeNumberIS) {

        String URL = "http://hotbitinfotech.com/frigo/remove_barcode.php";
        StringRequest request = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e(TAG, "onResponse: check  delete barcode " + response);

                Toast.makeText(getApplicationContext(), "Deleted.", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "onErrorResponse: " + error.getMessage());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                HashMap<String, String> param = new HashMap<>();

                param.put("p_delete", "delete");
                param.put("bar_code", barcodeNumberIS);

                Log.e(TAG, "getParams: "+param );
                return param;
            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(request);
    }

    @Override
    public void onBackPressed() {
        finish();
        startActivity(new Intent(BarcodeListItems.this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET));
        finish();
    }
}
