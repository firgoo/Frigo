package hotbitinfotech.com.frigo;

public class Common {
    public static String ROOT_URL = "http://hotbitinfotech.com/frigo/";
    public static String CheckBarcodeInfo = ROOT_URL + "get_product_info.php";
}
